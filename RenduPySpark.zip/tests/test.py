import pytest



class TestFoot(object):

    def test_avg(self):
        source_data = [

        ]


        expected_df =

        )

        assert(expected_df.collect() == actual_df.collect())